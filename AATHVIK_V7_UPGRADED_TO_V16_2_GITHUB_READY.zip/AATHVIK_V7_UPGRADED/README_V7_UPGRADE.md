# AATHVIK — V7 upgraded to V16.2

This project keeps the original AATHVIK applicationId/package (`com.aathvik.app`) and upgrades the V7 codebase with the later V16 study, PYQ hub, mock, current-affairs, PDF, FIGHTER and optional Google integration features.

## Update version
- versionCode: 14 (greater than V7's 6, so Android treats it as a newer version when the signing key is the same)
- versionName: 16.2

## Important for an existing installed APK
Android updates require the new APK to be signed with the same signing certificate as the installed old APK. GitHub Actions debug builds use a runner-generated debug key unless you configure a persistent signing key. If the old app was installed from a different key, uninstall/reinstall or configure the original keystore.

## GitHub Actions
The included workflow builds `app-debug.apk` and uploads it as `AATHVIK-debug-apk`.
