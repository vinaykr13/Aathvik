package com.aathvik.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.view.animation.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    SharedPreferences sp;
    Handler handler = new Handler();
    long studySeconds = 0;
    boolean running = false;
    final int BG=Color.rgb(5,10,20), SURFACE=Color.rgb(12,24,43), SURFACE2=Color.rgb(16,33,59), TEXT=Color.WHITE,
            MUTED=Color.rgb(157,174,201), BLUE=Color.rgb(45,128,255), CYAN=Color.rgb(37,202,220), GREEN=Color.rgb(35,194,143),
            PURPLE=Color.rgb(132,92,255), ORANGE=Color.rgb(255,145,55), PINK=Color.rgb(241,82,135);

    Runnable tick = new Runnable(){ public void run(){ if(running){ studySeconds++; sp.edit().putLong("study",studySeconds).apply(); updateTimer(); handler.postDelayed(this,1000); }}};

    static class Topic {
        String subject,name,theory,trick,example;
        Topic(String s,String n,String t,String k,String e){subject=s;name=n;theory=t;trick=k;example=e;}
    }
    ArrayList<Topic> topics = new ArrayList<>();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("aathvik",0);
        studySeconds=sp.getLong("study",0);
        seedTopics();
        buildShell();
        home();
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(size);return t;}
    TextView muted(String s){TextView t=tv(s,13);t.setTextColor(MUTED);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)r));return g;}
    GradientDrawable stroke(int color,int line,float r){GradientDrawable g=bg(color,r);g.setStroke(dp(1),line);return g;}
    LinearLayout card(int color){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(15),dp(16),dp(15));l.setBackground(bg(color,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(7),0,dp(7));l.setLayoutParams(p);return l;}
    Button action(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(12);b.setAllCaps(false);b.setMinHeight(dp(44));b.setPadding(dp(12),0,dp(12),0);b.setBackground(bg(color,15));return b;}
    void animateIn(View v,int delay){v.setAlpha(0f);v.setTranslationY(dp(10));v.animate().alpha(1f).translationY(0).setDuration(300).setStartDelay(delay).setInterpolator(new DecelerateInterpolator()).start();}
    void press(View v){v.animate().scaleX(.97f).scaleY(.97f).setDuration(80).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();}

    void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(18),dp(16),dp(18),dp(10));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv("AATHVIK",22);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);brand.addView(a);
        TextView tag=muted("Dream • Prepare • Achieve");tag.setTextSize(11);brand.addView(tag);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView bell=tv("◉",22);bell.setTextColor(CYAN);head.addView(bell);
        root.addView(head);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),0,dp(16),dp(10));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(dp(7),dp(6),dp(7),dp(6));nav.setBackground(bg(Color.rgb(8,17,31),0));
        String[] names={"⌂\nHome","▦\nSubjects","◷\nFocus","✓\nTests","◌\nProgress"};
        for(String n:names){Button x=action(n,Color.TRANSPARENT);x.setTextSize(11);nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));final String key=n;x.setOnClickListener(v->{press(v);if(key.contains("Home"))home();else if(key.contains("Subjects"))study();else if(key.contains("Focus"))focus();else if(key.contains("Tests"))mocks();else stats();});}
        root.addView(nav);setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void section(String name,String sub){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView a=tv(name,20);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(a,new LinearLayout.LayoutParams(0,-2,1));row.addView(muted(sub));content.addView(row);animateIn(row,0);}

    void home(){
        clear();
        TextView hi=tv("Hello, Aspirant 👋",25);hi.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(hi);animateIn(hi,0);
        TextView sub=muted("Your preparation. Your pace. Your selection.");content.addView(sub);animateIn(sub,40);
        LinearLayout hero=card(SURFACE2);hero.addView(label("SSC CGL 2026 • YOUR MISSION"));
        TextView eh=tv("Selection is the goal.\nConsistency is the strategy.",21);eh.setTypeface(Typeface.DEFAULT,Typeface.BOLD);eh.setPadding(0,dp(8),0,dp(8));hero.addView(eh);
        LinearLayout er=new LinearLayout(this);TextView days=tv("244\nDAYS",20);days.setTypeface(Typeface.DEFAULT,Typeface.BOLD);er.addView(days,new LinearLayout.LayoutParams(0,-2,1));TextView pct=tv("FOCUS\n"+formatShort(studySeconds),13);pct.setTextColor(CYAN);er.addView(pct);hero.addView(er);
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(28800);p.setProgress((int)Math.min(28800,studySeconds));p.setProgressTintList(android.content.res.ColorStateList.valueOf(BLUE));hero.addView(p);content.addView(hero);animateIn(hero,80);
        section("Continue preparation","Today");
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.HORIZONTAL);LinearLayout a=mini("▶","Continue\nStudying",BLUE);a.setOnClickListener(v->{press(v);study();});LinearLayout b=mini("↻","Revision\nPlan",GREEN);b.setOnClickListener(v->{press(v);study();});grid.addView(a,new LinearLayout.LayoutParams(0,dp(104),1));grid.addView(b,new LinearLayout.LayoutParams(0,dp(104),1));content.addView(grid);animateIn(grid,120);
        LinearLayout grid2=new LinearLayout(this);grid2.setOrientation(LinearLayout.HORIZONTAL);LinearLayout c=mini("▣","Mock\nTests",PURPLE);c.setOnClickListener(v->{press(v);mocks();});LinearLayout d=mini("⚡","FIGHTER\nAI Doubt",PINK);d.setOnClickListener(v->{press(v);fighter();});grid2.addView(c,new LinearLayout.LayoutParams(0,dp(104),1));grid2.addView(d,new LinearLayout.LayoutParams(0,dp(104),1));content.addView(grid2);animateIn(grid2,160);
        LinearLayout lib=card(SURFACE);lib.addView(label("STUDY LIBRARY"));lib.addView(tv("Complete topic-wise preparation",18));lib.addView(muted("Theory • Tricks • Examples • Videos • References"));Button open=action("EXPLORE SUBJECTS  →",BLUE);open.setOnClickListener(v->{press(v);study();});lib.addView(open);content.addView(lib);animateIn(lib,200);
        LinearLayout refs=card(Color.rgb(10,30,42));refs.addView(tv("📚 Smart References",16));refs.addView(muted("Official + trusted study resources in one place."));Button rb=action("OPEN REFERENCES",CYAN);rb.setOnClickListener(v->{press(v);references();});refs.addView(rb);content.addView(refs);animateIn(refs,240);
    }
    TextView label(String s){TextView t=tv(s.toUpperCase(Locale.US),11);t.setTextColor(CYAN);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout mini(String icon,String text,int color){LinearLayout c=card(SURFACE);c.setGravity(Gravity.CENTER);c.setPadding(dp(8),dp(9),dp(8),dp(9));TextView i=tv(icon,25);i.setTextColor(color);i.setGravity(Gravity.CENTER);c.addView(i);TextView t=tv(text,13);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(t);LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)c.getLayoutParams();p.setMargins(dp(4),dp(6),dp(4),dp(6));c.setLayoutParams(p);return c;}

    void study(){
        clear();section("SSC CGL Subjects","Topic Library");TextView info=muted("Every topic now has Theory + Tricks + Example + Video + Reference.");content.addView(info);animateIn(info,30);
        LinkedHashMap<String,ArrayList<Topic>> groups=new LinkedHashMap<>();for(Topic t:topics){groups.computeIfAbsent(t.subject,k->new ArrayList<>()).add(t);}
        int[] colors={BLUE,PURPLE,PINK,ORANGE,CYAN,GREEN};int idx=0;
        for(String subject:groups.keySet()){
            ArrayList<Topic> list=groups.get(subject);LinearLayout c=card(SURFACE);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView sh=tv(subject,17);sh.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(sh,new LinearLayout.LayoutParams(0,-2,1));TextView count=tv(list.size()+" topics",12);count.setTextColor(colors[idx%colors.length]);top.addView(count);c.addView(top);
            for(Topic tp:list){Button b=action((sp.getBoolean("done_"+tp.name,false)?"✓  ":"○  ")+tp.name,Color.TRANSPARENT);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setTextColor(TEXT);b.setBackground(stroke(Color.rgb(10,24,43),Color.rgb(31,57,90),14));b.setOnClickListener(v->{press(v);showTopic(tp);});c.addView(b,new LinearLayout.LayoutParams(-1,dp(48)));}
            content.addView(c);animateIn(c,Math.min(350,idx*35));idx++;
        }
    }

    void showTopic(Topic t){
        clear();LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);Button back=action("‹",Color.TRANSPARENT);back.setTextSize(28);back.setOnClickListener(v->{press(v);study();});top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));top.addView(tv(t.name,20),new LinearLayout.LayoutParams(0,-2,1));content.addView(top);content.addView(muted(t.subject));
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(0,dp(8),0,dp(8));Button theoryTab=action("Theory",BLUE);Button videoTab=action("▶ Video",Color.rgb(21,71,91));Button refTab=action("↗ Reference",Color.rgb(48,43,82));tabs.addView(theoryTab,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(videoTab,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(refTab,new LinearLayout.LayoutParams(0,dp(44),1));content.addView(tabs);
        LinearLayout theory=card(SURFACE);theory.addView(label("THEORY"));TextView th=tv(t.theory,15);th.setLineSpacing(0,1.18f);theory.addView(th);content.addView(theory);
        LinearLayout trick=card(Color.rgb(39,31,12));trick.addView(label("TRICK / SHORTCUT"));TextView tr=tv("💡 "+t.trick,15);tr.setLineSpacing(0,1.1f);trick.addView(tr);content.addView(trick);
        LinearLayout ex=card(Color.rgb(10,36,36));ex.addView(label("EXAMPLE"));TextView et=tv("✍️ "+t.example,15);et.setLineSpacing(0,1.1f);ex.addView(et);content.addView(ex);
        Button done=action(sp.getBoolean("done_"+t.name,false)?"✓ TOPIC COMPLETED":"MARK TOPIC COMPLETE",GREEN);done.setOnClickListener(v->{press(v);sp.edit().putBoolean("done_"+t.name,true).apply();done.setText("✓ TOPIC COMPLETED");});content.addView(done);animateIn(theory,0);animateIn(trick,60);animateIn(ex,120);animateIn(done,160);
        videoTab.setOnClickListener(v->{press(v);openVideoSearch(t);});refTab.setOnClickListener(v->{press(v);openReferenceSearch(t);});
    }

    void openVideoSearch(Topic t){String q=Uri.encode("SSC CGL "+t.subject+" "+t.name+" Hindi lecture");web("Video • "+t.name,"https://www.youtube.com/results?search_query="+q);}
    void openReferenceSearch(Topic t){String q=Uri.encode("SSC CGL "+t.subject+" "+t.name+" notes reference");web("Reference • "+t.name,"https://www.google.com/search?q="+q);}
    void web(String title,String url){
        clear();LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=action("‹",Color.TRANSPARENT);back.setTextSize(28);back.setOnClickListener(v->{press(v);study();});head.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));head.addView(tv(title,18),new LinearLayout.LayoutParams(0,-2,1));content.addView(head);
        WebView w=new WebView(this);w.setBackgroundColor(BG);w.setWebViewClient(new WebViewClient());WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(true);w.loadUrl(url);content.addView(w,new LinearLayout.LayoutParams(-1,dp(620)));animateIn(w,0);
    }
    void references(){
        clear();section("References","Trusted resources");
        String[][] refs={{"SSC Official Website","Notices, syllabus and official updates","https://ssc.gov.in/"},{"NCERT","School-level fundamentals for History, Geography, Science and more","https://ncert.nic.in/"},{"RBI","Banking and monetary-policy basics","https://www.rbi.org.in/"},{"PIB","Government and current-affairs reference","https://pib.gov.in/"}};
        for(String[] r:refs){LinearLayout c=card(SURFACE);c.addView(tv(r[0],17));c.addView(muted(r[1]));Button b=action("OPEN RESOURCE  ↗",BLUE);b.setOnClickListener(v->{press(v);web(r[0],r[2]);});c.addView(b);content.addView(c);animateIn(c,80);}
    }

    void focus(){clear();section("Focus Timer","Deep work");LinearLayout c=card(SURFACE2);TextView timer=tv(format(studySeconds),46);timer.setGravity(Gravity.CENTER);timer.setTag("timer");timer.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(timer);TextView sub=muted("Every focused minute counts.");sub.setGravity(Gravity.CENTER);c.addView(sub);Button start=action(running?"PAUSE FOCUS":"START FOCUS",BLUE);start.setOnClickListener(v->{press(v);running=!running;if(running){handler.post(tick);start.setText("PAUSE FOCUS");}else start.setText("RESUME FOCUS");});c.addView(start);Button reset=action("RESET TIMER",Color.rgb(35,48,67));reset.setOnClickListener(v->{press(v);running=false;studySeconds=0;sp.edit().putLong("study",0).apply();updateTimer();});c.addView(reset);content.addView(c);animateIn(c,0);}
    void updateTimer(){TextView t=findByTag(content,"timer");if(t!=null)t.setText(format(studySeconds));}
    TextView findByTag(View v,String tag){if(tag.equals(v.getTag())&&v instanceof TextView)return(TextView)v;if(v instanceof ViewGroup){for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView r=findByTag(((ViewGroup)v).getChildAt(i),tag);if(r!=null)return r;}}return null;}
    String format(long s){return String.format(Locale.US,"%02dh %02dm %02ds",s/3600,(s%3600)/60,s%60);}String formatShort(long s){return String.format(Locale.US,"%02dh %02dm",s/3600,(s%3600)/60);}

    void mocks(){clear();section("Mock Tests","Track performance");LinearLayout c=card(SURFACE2);c.addView(label("NEW MOCK RESULT"));EditText score=new EditText(this);score.setHint("Score");score.setTextColor(TEXT);score.setHintTextColor(MUTED);c.addView(score);EditText total=new EditText(this);total.setHint("Total marks");total.setTextColor(TEXT);total.setHintTextColor(MUTED);c.addView(total);Button save=action("SAVE MOCK RESULT",PURPLE);save.setOnClickListener(v->{press(v);sp.edit().putInt("mock_count",sp.getInt("mock_count",0)+1).apply();Toast.makeText(this,"Mock saved ✓",Toast.LENGTH_SHORT).show();});c.addView(save);content.addView(c);content.addView(cardText("Mocks attempted: "+sp.getInt("mock_count",0)));}
    void stats(){clear();section("My Progress","Your preparation");int done=0;for(Topic t:topics)if(sp.getBoolean("done_"+t.name,false))done++;int percent=topics.isEmpty()?0:(done*100/topics.size());LinearLayout hero=card(SURFACE2);TextView p=tv(percent+"%",42);p.setTypeface(Typeface.DEFAULT,Typeface.BOLD);p.setGravity(Gravity.CENTER);hero.addView(p);TextView q=tv("Overall theory progress",14);q.setTextColor(CYAN);q.setGravity(Gravity.CENTER);hero.addView(q);hero.addView(muted(done+" of "+topics.size()+" theory topics completed"));content.addView(hero);content.addView(cardText("⏱ Study time: "+format(studySeconds)));content.addView(cardText("📝 Mocks attempted: "+sp.getInt("mock_count",0)));content.addView(cardText("📚 References and videos are available topic-wise."));content.addView(cardText("🔥 Consistency beats motivation."));}
    LinearLayout cardText(String s){LinearLayout c=card(SURFACE);c.addView(tv(s,16));return c;}
    void fighter(){clear();section("FIGHTER","AI Doubt Solver");LinearLayout c=card(SURFACE2);c.addView(muted("Maths • Reasoning • English • General Awareness"));EditText q=new EditText(this);q.setHint("Apna doubt likho...");q.setHintTextColor(MUTED);q.setTextColor(TEXT);q.setMinLines(5);q.setGravity(Gravity.TOP);c.addView(q);Button ask=action("🥊 ASK FIGHTER",PINK);ask.setOnClickListener(v->{press(v);String x=q.getText().toString().trim();if(x.isEmpty())return;new AlertDialog.Builder(this).setTitle("FIGHTER").setMessage("Step 1: Concept identify karo.\n\nStep 2: Theory padho.\n\nStep 3: Step-by-step solve karo.\n\nStep 4: Shortcut check karo.\n\nStep 5: Similar question practice karo.\n\nDoubt received:\n"+x).setPositiveButton("OK",null).show();});c.addView(ask);content.addView(c);animateIn(c,0);}

    void seedTopics(){
        add("Quantitative Aptitude","Number System","Natural, whole, integer, rational and irrational numbers; factors, multiples, HCF, LCM and divisibility.","Make a one-page divisibility checklist.","LCM × HCF = product of two positive integers.");
        add("Quantitative Aptitude","Percentage","Percentage means per hundred. Revise conversions, comparison and successive increase/decrease.","x% of y = y% of x; successive changes use multiplication of factors.","20% up then 10% down = 1.2×0.9 = +8%.");
        add("Quantitative Aptitude","Profit & Loss","Profit = SP−CP and Loss = CP−SP. Revise profit/loss percentage, discount and marked price.","Profit p% → SP=CP(1+p/100).","CP ₹500, profit 20% → SP ₹600.");
        add("Quantitative Aptitude","Ratio & Proportion","Ratios compare quantities in the same units; proportion equates ratios. Revise direct/inverse proportion and partnership.","Convert units first, then simplify.","2:3 = 8:12.");
        add("Quantitative Aptitude","Average","Average = total ÷ number. Revise combined average and replacement questions.","Total = average × number.","Average of 10,20,30 = 20.");
        add("Quantitative Aptitude","Time & Work","Work is handled through rates. If A finishes in x days, one-day work is 1/x; combined rates add.","LCM of days often makes total work simple.","10-day + 15-day workers together finish in 6 days.");
        add("Quantitative Aptitude","SI & CI","Simple interest uses principal; compound interest adds interest to the amount periodically.","For 2 years, CI−SI=P(r/100)^2.","₹1000 at 10% for 2 years: SI ₹200, CI ₹210.");
        add("Quantitative Aptitude","Time Speed Distance","Speed = distance/time. km/h→m/s multiply 5/18. Revise relative speed and trains.","Equal-distance average speed = 2ab/(a+b).","60 km/h for 2 hours = 120 km.");
        add("Quantitative Aptitude","Algebra","Revise identities, linear equations, factorisation and quadratic basics.","Memorise (a+b)^2, (a−b)^2 and a²−b².","(x+5)(x−5)=x²−25.");
        add("Quantitative Aptitude","Geometry","Study lines, angles, triangles, quadrilaterals and circles; focus on properties and theorems.","Draw the figure before applying a theorem.","Angles of a triangle sum to 180°.");
        add("Quantitative Aptitude","Mensuration","Revise perimeter, area and volume of common shapes with unit conversion.","Write the required unit beside the formula.","Circle area = πr².");
        add("Quantitative Aptitude","Trigonometry","Learn basic ratios, standard angles, identities and heights/distances.","SOH-CAH-TOA for right triangles.","sin 30° = 1/2.");
        add("Reasoning","Analogy","Find the exact relationship in the first pair and apply it to the second.","Turn the first pair into a sentence.","Book:Read :: Food:Eat.");
        add("Reasoning","Series","Check differences, ratios, alternating terms and alphabet positions.","Start with first differences; then check second differences.","2,5,10,17 → next 26.");
        add("Reasoning","Coding Decoding","Use alphabet positions and compare character-wise transformations.","Write A=1 to Z=26 for difficult codes.","CAT shifted +1 becomes DBU.");
        add("Reasoning","Blood Relation","Convert statements into a small family tree and track gender/generation.","Draw instead of solving mentally.","Mother's brother = maternal uncle.");
        add("Reasoning","Direction Sense","Fix North at top and track turns; distinguish final direction from distance.","Use a simple compass sketch.","Facing North, right turn = East.");
        add("Reasoning","Syllogism","Statements define sets; conclusions must follow necessarily.","Use Venn diagrams and never assume extra information.","All A are B means A is a subset of B.");
        add("Reasoning","Venn Diagram","Represent set relationships, overlaps and classifications visually.","Translate both, only, neither and at least into regions.","Cricket + football players go in the overlap.");
        add("Reasoning","Seating Arrangement","Arrange people using fixed clues first, then relative clues; track perspective.","Place the most constrained pair first.","If A is immediately left of B, keep AB together initially.");
        add("English Language","Parts of Speech","Noun, pronoun, adjective, verb, adverb, preposition, conjunction and interjection describe word functions.","Ask what the word is doing in the sentence.","Quickly is usually an adverb.");
        add("English Language","Tenses","Revise present, past and future in simple, continuous, perfect and perfect continuous forms.","Learn helping-verb patterns with time markers.","She has finished = present perfect.");
        add("English Language","Articles","A/an are indefinite; the is definite. Choice depends on sound and specificity.","an hour but a university.","He is an honest man.");
        add("English Language","Prepositions","Prepositions show time, place, direction and relationships; revise common fixed combinations.","Learn high-frequency phrases together.","She is good at English.");
        add("English Language","Subject Verb Agreement","The verb agrees with the true grammatical subject, not the nearest noun.","Remove interrupting phrases and find the subject.","The list of items is on the table.");
        add("English Language","Active Passive Voice","Active highlights the doer; passive highlights the receiver while preserving tense.","Object of active sentence becomes passive subject.","They write a letter → A letter is written by them.");
        add("English Language","Direct Indirect Speech","Reported speech changes pronouns, tense and time expressions according to context.","Identify statement/question/command first.","He said, I am tired → He said that he was tired.");
        add("English Language","Error Detection","Scan agreement, tense, articles, prepositions, modifiers, pronouns and parallelism.","Use the same scan order every time.","She do not know → She does not know.");
        add("English Language","Vocabulary & Idioms","Build synonyms, antonyms, one-word substitutions, roots and common idioms with spaced revision.","Keep confusing words in pairs.","Break the ice = start a conversation.");
        add("General Awareness — History","Ancient India","Indus Valley, Vedic period, Mahajanapadas, Buddhism, Jainism, Mauryas, Guptas and culture.","Use a one-page chronology.","Ashoka is associated with the Mauryan Empire.");
        add("General Awareness — History","Medieval India","Delhi Sultanate, Mughals, Bhakti-Sufi traditions, Vijayanagara and Marathas.","Founder → Capital → Major ruler → feature.","Akbar is a major Mughal ruler.");
        add("General Awareness — History","Modern India","European expansion, British rule, 1857, INC, national movements and independence.","Cause → Leader → Year → Method → Outcome.","Non-Cooperation began in 1920.");
        add("General Awareness — Geography","Physical Geography","Earth interior, rocks, plate tectonics, mountains, rivers, atmosphere, climate and oceans.","Draw diagrams for layers and pressure belts.","Weather is short-term; climate is long-term.");
        add("General Awareness — Geography","Indian Geography","Physiography, rivers, soils, monsoon, agriculture, minerals, industries and maps.","Use map-based revision.","Black soil is strongly associated with cotton regions.");
        add("General Awareness — Polity","Constitution Basics","Study Preamble, Fundamental Rights, DPSP, Duties and Union/State structure.","Map Legislature → Executive → Judiciary.","Fundamental Rights are mainly in Part III.");
        add("General Awareness — Polity","Parliament & President","Study Houses, law-making, money bills, committees and executive accountability.","Compare Lok Sabha and Rajya Sabha in a table.","Money Bills have a special Lok Sabha role.");
        add("General Awareness — Polity","Judiciary & Bodies","Study courts, judicial review, writs, Election Commission, CAG, UPSC and Finance Commission.","Source → appointment → tenure → function.","Habeas corpus concerns unlawful detention.");
        add("General Awareness — Economy","Basic Economics","Demand, supply, GDP, inflation, real vs nominal values and basic economic concepts.","Separate stock vs flow and real vs nominal.","Inflation is a sustained rise in general price level.");
        add("General Awareness — Economy","Banking & Monetary Policy","RBI, banks, deposits, loans, repo, reverse repo, CRR and SLR.","Make an RBI-tool → liquidity-effect sheet.","Higher CRR generally reduces lendable funds.");
        add("General Awareness — Economy","Budget & Fiscal Policy","Revenue, expenditure, borrowing, direct/indirect taxes and fiscal deficit.","Fiscal = government budget; monetary = money/credit.","Fiscal deficit reflects a financing gap.");
        add("General Awareness — Science","Physics Basics","Units, motion, force, work, energy, power, heat, sound, light, electricity and magnetism.","Pair every formula with SI unit + example.","Power = work/time; watt is SI unit.");
        add("General Awareness — Science","Chemistry Basics","Matter, atoms, periodic trends, reactions, acids/bases/salts, metals and carbon compounds.","Learn reaction as reactants → products + use.","Acid + base generally gives salt + water.");
        add("General Awareness — Science","Biology Basics","Cell, tissues, human systems, nutrition, diseases, genetics, plants, ecology and evolution.","Organ → function → hormone/enzyme → disorder.","Hemoglobin carries oxygen in RBCs.");
        add("General Awareness — Science","Environment & Ecology","Ecosystems, food chains, biodiversity, pollution, climate change and conservation.","Draw producers → consumers → decomposers.","Energy decreases across trophic levels.");
        add("General Awareness — Static GK","Art Culture & Misc","Classical dances, festivals, monuments, books/authors, awards, sports terms and important days.","Use theme-based flashcards.","Learn each dance with region + feature.");
        add("General Awareness — Computer","Computer Fundamentals","Hardware, software, CPU, memory, storage, OS, networks, internet, cybersecurity and shortcuts.","Memorise common shortcut pairs.","Ctrl+C copies; Ctrl+V pastes.");
    }
    void add(String s,String n,String t,String k,String e){topics.add(new Topic(s,n,t,k,e));}
}
