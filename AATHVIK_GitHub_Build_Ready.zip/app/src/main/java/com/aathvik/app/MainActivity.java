package com.aathvik.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title;
    final int BG=Color.rgb(16,19,26), CARD=Color.rgb(24,28,37), TEXT=Color.WHITE, MUTED=Color.rgb(150,156,170), ACCENT=Color.rgb(124,140,255);
    android.content.SharedPreferences sp;
    long studySeconds=0; Handler handler=new Handler(); boolean running=false;
    Runnable tick= new Runnable(){ public void run(){ if(running){ studySeconds++; sp.edit().putLong("study",studySeconds).apply(); updateTimer(); handler.postDelayed(this,1000); } }};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); sp=getSharedPreferences("aathvik",0); studySeconds=sp.getLong("study",0); buildShell(); home();
    }
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(TEXT); t.setTextSize(size); t.setPadding(16,12,16,12); return t; }
    TextView muted(String s){ TextView t=tv(s,13); t.setTextColor(MUTED); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(13); b.setAllCaps(false); b.setBackgroundColor(ACCENT); return b; }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(10,10,10,10); l.setBackgroundColor(CARD); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,10,0,10); l.setLayoutParams(p); return l; }
    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(18,18,18,8);
        title=tv("AATHVIK",26); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.addView(title); head.addView(muted("Study • Practice • Progress"));
        root.addView(head); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(Color.rgb(20,23,32));
        String[] names={"⌂\nHome","📚\nStudy","⏱\nFocus","📝\nMocks","📊\nStats"};
        for(String n:names){ Button x=new Button(this); x.setText(n); x.setTextColor(TEXT); x.setTextSize(11); x.setAllCaps(false); x.setBackgroundColor(Color.TRANSPARENT); nav.addView(x,new LinearLayout.LayoutParams(0,70,1)); final String key=n; x.setOnClickListener(v->{ if(key.contains("Home"))home(); else if(key.contains("Study"))study(); else if(key.contains("Focus"))focus(); else if(key.contains("Mocks"))mocks(); else stats();});}
        root.addView(nav); setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void home(){
        clear(); content.addView(tv("Good morning 👋",22));
        LinearLayout c=card(); c.addView(muted("TODAY'S STUDY")); TextView h=tv(format(studySeconds),32); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.setTag("homeTimer"); c.addView(h);
        ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); pb.setMax(28800); pb.setProgress((int)Math.min(28800,studySeconds)); c.addView(pb); c.addView(muted("Daily target: 8 hours")); content.addView(c);
        LinearLayout grid=card(); grid.addView(tv("🎯 Quick Actions",18));
        Button t=btn("⏱ Start Focus"); t.setOnClickListener(v->focus()); grid.addView(t);
        Button f=btn("🥊 Ask FIGHTER"); f.setOnClickListener(v->fighter()); grid.addView(f); content.addView(grid);
        LinearLayout tasks=card(); tasks.addView(tv("Today's Tasks",18)); tasks.addView(muted("• Quant — Percentage\n• English — Vocabulary\n• Reasoning — Series\n• GA — Polity")); content.addView(tasks);
    }
    void study(){
        clear(); content.addView(tv("📚 Study Library",22)); content.addView(muted("Topic-wise theory, figures, formulas and tricks"));
        String[][] data={{"Quant","Number System","Percentage","Profit & Loss","Ratio & Proportion","Average","Time & Work","Algebra","Geometry","Trigonometry","Mensuration"},
        {"Reasoning","Analogy","Classification","Series","Coding-Decoding","Blood Relation","Direction","Syllogism","Venn Diagram","Mirror/Water Image","Counting Figures"},
        {"English","Parts of Speech","Tenses","Subject-Verb Agreement","Articles","Prepositions","Voice","Narration","Error Detection","Vocabulary","Idioms & Phrases"},
        {"General Awareness","History","Geography","Polity","Economics","Physics","Chemistry","Biology","Static GK","Art & Culture","Environment"}};
        for(String[] s:data){ LinearLayout c=card(); TextView sh=tv(s[0],19); sh.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(sh);
            for(int i=1;i<s.length;i++){ final String topic=s[i]; Button b=btn("○ "+topic); b.setOnClickListener(v->topic(topic)); c.addView(b); } content.addView(c);}
    }
    void topic(String topic){
        new AlertDialog.Builder(this).setTitle(topic)
        .setMessage(theory(topic)+"\n\n💡 QUICK TRICK\n"+trick(topic)+"\n\n✍️ PRACTICE\nConcept ko apply karne ke liye basic questions se start karo, phir PYQs solve karo.")
        .setPositiveButton("Mark Completed", (d,w)->sp.edit().putBoolean("done_"+topic,true).apply())
        .setNegativeButton("Close",null).show();
    }
    String theory(String t){ if(t.equals("Percentage"))return "Percentage means per hundred. x% = x/100. Increase/decrease ko original value ke reference se calculate karo."; if(t.equals("Profit & Loss"))return "Profit = SP − CP. Loss = CP − SP. Profit%/Loss% ka base CP hota hai."; if(t.equals("Average"))return "Average = total ÷ number of observations. Total = average × count."; if(t.equals("Ratio & Proportion"))return "Ratio a:b means a/b. Proportion mein two ratios equal hote hain: a:b = c:d."; if(t.equals("Number System"))return "Natural, whole, integer, rational and irrational numbers ke properties samjho."; if(t.equals("Trigonometry"))return "Right triangle mein sin, cos aur tan ratios ka use hota hai."; if(t.equals("Polity"))return "Constitution, Fundamental Rights, DPSP, Parliament aur constitutional bodies ko structured way mein revise karo."; return "Definition → rules/formulas → examples → PYQs. Topic ko short notes aur revision cycle ke saath padho."; }
    String trick(String t){ if(t.equals("Percentage"))return "10% = ÷10, 5% = ÷20, 1% = ÷100. Fraction conversion se calculation fast hoti hai."; if(t.equals("Profit & Loss"))return "Percentage questions mein CP ko 100 maan kar calculation simplify karna useful hota hai."; if(t.equals("Average"))return "Assumed average method: deviations ka sum use karke correction nikalo."; if(t.equals("Trigonometry"))return "SOH-CAH-TOA ko right-triangle ratios ke anchor mnemonic ki tarah use karo."; return "FIGHTER se bolo: 'is topic ki 5-second trick batao'."; }
    void focus(){
        clear(); content.addView(tv("⏱️ Focus Timer",22)); LinearLayout c=card(); TextView timer=tv(format(studySeconds),52); timer.setGravity(Gravity.CENTER); timer.setTag("timer"); c.addView(timer);
        TextView sub=muted("Current session"); sub.setGravity(Gravity.CENTER); c.addView(sub);
        Button start=btn(running?"PAUSE":"START FOCUS"); start.setOnClickListener(v->{running=!running; if(running){handler.post(tick); start.setText("PAUSE");}else start.setText("RESUME");}); c.addView(start); Button reset=btn("RESET SESSION"); reset.setOnClickListener(v->{running=false; studySeconds=0; sp.edit().putLong("study",0).apply(); updateTimer();}); c.addView(reset); content.addView(c);
    }
    void updateTimer(){ TextView t=findByTag("timer"); if(t!=null)t.setText(format(studySeconds)); TextView h=findByTag("homeTimer"); if(h!=null)h.setText(format(studySeconds)); }
    TextView findByTag(String tag){ return findTag(content,tag); }
    TextView findTag(View v,String tag){ if(tag.equals(v.getTag()))return (TextView)v; if(v instanceof ViewGroup){for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView r=findTag(((ViewGroup)v).getChildAt(i),tag);if(r!=null)return r;}}return null; }
    String format(long s){return String.format(Locale.US,"%02dh %02dm %02ds",s/3600,(s%3600)/60,s%60);}
    void mocks(){ clear(); content.addView(tv("📝 Mock Tracker",22)); LinearLayout c=card(); c.addView(muted("Add your mock result")); EditText score=new EditText(this); score.setHint("Score (e.g. 142)"); c.addView(score); EditText total=new EditText(this); total.setHint("Total marks (e.g. 200)"); c.addView(total); Button save=btn("SAVE MOCK"); save.setOnClickListener(v->{sp.edit().putInt("mock_count",sp.getInt("mock_count",0)+1).apply(); Toast.makeText(this,"Mock saved",Toast.LENGTH_SHORT).show();}); c.addView(save); content.addView(c); content.addView(cardText("Mocks attempted: "+sp.getInt("mock_count",0))); }
    void stats(){ clear(); content.addView(tv("📊 Progress",22)); content.addView(cardText("Study time: "+format(studySeconds))); content.addView(cardText("Mocks attempted: "+sp.getInt("mock_count",0))); content.addView(cardText("Keep going — consistency beats motivation. 🔥")); }
    LinearLayout cardText(String s){LinearLayout c=card();c.addView(tv(s,17));return c;}
    void fighter(){
        clear(); content.addView(tv("🥊 FIGHTER",22)); content.addView(muted("AI doubt solver"));
        LinearLayout c=card(); EditText q=new EditText(this); q.setHint("Apna doubt likho..."); q.setMinLines(5); c.addView(q);
        Button ask=btn("ASK FIGHTER"); ask.setOnClickListener(v->{String x=q.getText().toString().trim(); if(x.isEmpty())return; new AlertDialog.Builder(this).setTitle("FIGHTER").setMessage("Step 1: Concept identify karo.\n\nStep 2: Basic theory samjho.\n\nStep 3: Question ko step-by-step solve karo.\n\nStep 4: Shortcut/trick check karo.\n\nStep 5: Similar question practice karo.\n\nDoubt received:\n"+x+"\n\nLive AI answers ke liye production backend/API connection V2 mein add kiya jayega.").setPositiveButton("OK",null).show();}); c.addView(ask); content.addView(c);
    }
}
