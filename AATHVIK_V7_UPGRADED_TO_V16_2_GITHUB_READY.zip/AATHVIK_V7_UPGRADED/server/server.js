const express = require('express');
const crypto = require('crypto');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const app = express();
const PORT = process.env.PORT || 8080;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'change-this-token';
const APP_UPLOAD_TOKEN = process.env.APP_UPLOAD_TOKEN || 'aathvik-upload-v10';
const DATA = path.join(__dirname, '..', 'content.json');
const PDF_DIR = path.join(__dirname, 'uploads'); fs.mkdirSync(PDF_DIR,{recursive:true});
const upload = multer({storage:multer.diskStorage({destination:PDF_DIR,filename:(req,file,cb)=>cb(null,Date.now()+'-'+String(file.originalname||'study.pdf').replace(/[^a-zA-Z0-9._-]/g,'_'))}),limits:{fileSize:25*1024*1024},fileFilter:(req,file,cb)=>cb(null,file.mimetype==='application/pdf')});
app.use(cors()); app.use(express.json({limit:'4mb'})); app.use('/uploads',express.static(PDF_DIR));
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const FIGHTER_MODEL = process.env.FIGHTER_MODEL || 'gpt-5.6-luna';
const FREE_FIRST = process.env.FREE_FIRST !== 'false';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || '';
const GOOGLE_SCOPES = 'openid email profile https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/yt-analytics.readonly https://www.googleapis.com/auth/drive.readonly';
const googleStates = new Map();
const googleTokens = new Map();
function googleConfigured(){ return !!(GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET && GOOGLE_REDIRECT_URI); }
function esc(v){ return encodeURIComponent(String(v||'')); }

app.get('/auth/google/start',(req,res)=>{
  if(!googleConfigured()) return res.status(503).send('Google OAuth is not configured on the AATHVIK server.');
  const state=crypto.randomUUID();
  const appRedirect=String(req.query.app_redirect||'aathvik://google-callback');
  googleStates.set(state,{appRedirect,createdAt:Date.now()});
  const url='https://accounts.google.com/o/oauth2/v2/auth?'+new URLSearchParams({client_id:GOOGLE_CLIENT_ID,redirect_uri:GOOGLE_REDIRECT_URI,response_type:'code',scope:GOOGLE_SCOPES,access_type:'offline',prompt:'consent',state}).toString();
  res.redirect(url);
});

app.get('/auth/google/callback',async(req,res)=>{
  try{
    const state=String(req.query.state||''); const rec=googleStates.get(state); googleStates.delete(state);
    if(!rec || Date.now()-rec.createdAt>10*60*1000) return res.status(400).send('Invalid or expired Google OAuth state.');
    if(req.query.error) return res.redirect(rec.appRedirect+'?status=cancelled');
    const tokenRes=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code:String(req.query.code||''),client_id:GOOGLE_CLIENT_ID,client_secret:GOOGLE_CLIENT_SECRET,redirect_uri:GOOGLE_REDIRECT_URI,grant_type:'authorization_code'})});
    const tokens=await tokenRes.json(); if(!tokenRes.ok) return res.status(400).json({error:tokens?.error_description||'Google token exchange failed'});
    const profileRes=await fetch('https://www.googleapis.com/oauth2/v3/userinfo',{headers:{Authorization:`Bearer ${tokens.access_token}`}});
    const profile=await profileRes.json();
    const key=crypto.randomUUID(); googleTokens.set(key,{tokens,profile,createdAt:Date.now()});
    const redirect=rec.appRedirect+'?status=success&email='+esc(profile.email||'Google account')+'&token='+esc(key);
    res.redirect(redirect);
  }catch(e){res.status(500).send(e.message||'Google OAuth error');}
});

app.get('/api/google/status',(req,res)=>{
  const key=String(req.query.token||''); const rec=googleTokens.get(key);
  if(!rec) return res.status(401).json({connected:false});
  res.json({connected:true,email:rec.profile?.email||null,name:rec.profile?.name||null,picture:rec.profile?.picture||null});
});

app.get('/api/google/youtube/videos',async(req,res)=>{
  const rec=googleTokens.get(String(req.query.token||'')); if(!rec) return res.status(401).json({error:'Not connected'});
  try{ const r=await fetch('https://www.googleapis.com/youtube/v3/search?part=snippet&forMine=true&type=video&maxResults=25&order=date',{headers:{Authorization:`Bearer ${rec.tokens.access_token}`}}); const d=await r.json(); if(!r.ok)return res.status(r.status).json(d); res.json(d); }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/google/drive/files',async(req,res)=>{
  const rec=googleTokens.get(String(req.query.token||'')); if(!rec) return res.status(401).json({error:'Not connected'});
  try{ const q="trashed=false"; const r=await fetch('https://www.googleapis.com/drive/v3/files?'+new URLSearchParams({q,fields:'files(id,name,mimeType,modifiedTime,webViewLink)',pageSize:'50',orderBy:'modifiedTime desc'}),{headers:{Authorization:`Bearer ${rec.tokens.access_token}`}}); const d=await r.json(); if(!r.ok)return res.status(r.status).json(d); res.json(d); }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/google/youtube/analytics',async(req,res)=>{
  const rec=googleTokens.get(String(req.query.token||'')); if(!rec) return res.status(401).json({error:'Not connected'});
  try{ const end=new Date(); const start=new Date(end.getTime()-28*86400000); const fmt=x=>x.toISOString().slice(0,10); const url='https://youtubeanalytics.googleapis.com/v2/reports?'+new URLSearchParams({ids:'channel==MINE',startDate:fmt(start),endDate:fmt(end),metrics:'views,likes,comments,subscribersGained',dimensions:'day',sort:'day'}); const r=await fetch(url,{headers:{Authorization:`Bearer ${rec.tokens.access_token}`}}); const d=await r.json(); if(!r.ok)return res.status(r.status).json(d); res.json(d); }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/google/youtube/channel',async(req,res)=>{
  const rec=googleTokens.get(String(req.query.token||'')); if(!rec) return res.status(401).json({error:'Not connected'});
  try{ const r=await fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true',{headers:{Authorization:`Bearer ${rec.tokens.access_token}`}}); const d=await r.json(); if(!r.ok)return res.status(r.status).json(d); res.json(d); }catch(e){res.status(500).json({error:e.message});}
});

function read(){ return JSON.parse(fs.readFileSync(DATA,'utf8')); }
app.get('/api/content',(req,res)=>res.json(read()));
app.put('/api/content',(req,res)=>{ if(req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:'Unauthorized'}); if(!req.body || !Array.isArray(req.body.topics)) return res.status(400).json({error:'Invalid content'}); const data={...req.body,version:(read().version||0)+1,updatedAt:new Date().toISOString()}; fs.writeFileSync(DATA,JSON.stringify(data,null,2)); res.json(data); });
app.post('/api/fighter', async (req,res)=>{
  try{
    if(!OPENAI_API_KEY){
      const q=String(req.body?.question||'').trim();
      const answer='Offline FIGHTER: AI server is optional in Free-First mode.\n\nAATHVIK ke bundled topic modules me Theory, Concept, Formula, Trick, Example, PYQ, Solution aur Revision material available hai.\n\nQuestion: '+q+'\n\nTip: apne relevant topic ko open karke PYQ/Solution section dekho. Internet hone par optional AI server enable kiya ja sakta hai.';
      return res.json({answer,mode:'offline'});
    }
    const question=String(req.body?.question||'').trim();
    if(!question) return res.status(400).json({error:'Question is required'});
    if(question.length>8000) return res.status(400).json({error:'Question too long'});
    const r=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',
      headers:{'Authorization':`Bearer ${OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({
        model:FIGHTER_MODEL,
        instructions:'You are FIGHTER, a dedicated SSC CGL doubt-solving tutor. Answer in simple Hindi/Hinglish unless the user asks for English. Give the correct answer first, then step-by-step explanation, shortcut/trick where useful, and one similar practice question. For maths/reasoning, show calculations clearly. Do not invent facts. Keep the answer focused and exam-oriented.',
        input:question
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'OpenAI request failed'});
    const answer=data.output_text || (Array.isArray(data.output)?data.output.flatMap(x=>x.content||[]).map(x=>x.text||'').filter(Boolean).join('\n'):'');
    res.json({answer});
  }catch(e){res.status(500).json({error:e.message||'FIGHTER server error'});}
});

app.get('/api/pdfs',(req,res)=>{
  try{
    const files=fs.readdirSync(PDF_DIR).filter(x=>x.toLowerCase().endsWith('.pdf')).map(name=>({name:name.replace(/^\d+-/,''),url:'/uploads/'+encodeURIComponent(name),uploadedAt:fs.statSync(path.join(PDF_DIR,name)).mtime.toISOString()})).sort((a,b)=>b.uploadedAt.localeCompare(a.uploadedAt));
    res.json(files);
  }catch(e){res.status(500).json({error:e.message});}
});
app.post('/api/pdfs', (req,res,next)=>{ const auth=req.headers.authorization||''; if(auth !== `Bearer ${ADMIN_TOKEN}` && auth !== `Bearer ${APP_UPLOAD_TOKEN}`) return res.status(401).json({error:'Unauthorized'}); next(); }, upload.single('file'), async(req,res)=>{
  try{
    if(!req.file)return res.status(400).json({error:'PDF file required'});
    let extracted='';
    try{ const data=await pdfParse(fs.readFileSync(req.file.path)); extracted=(data.text||'').slice(0,12000); }catch(e){}
    const meta={name:req.file.originalname,size:req.file.size,uploadedAt:new Date().toISOString(),textPreview:extracted};
    fs.writeFileSync(req.file.path+'.json',JSON.stringify(meta,null,2));
    res.json({ok:true,name:req.file.originalname,size:req.file.size,textPreview:extracted});
  }catch(e){if(req.file)try{fs.unlinkSync(req.file.path)}catch(_){}res.status(500).json({error:e.message});}
});
app.post('/api/refresh',async(req,res)=>{
  if(req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:'Unauthorized'});
  try{
    const feeds=(process.env.NEWS_FEEDS||'').split(',').map(x=>x.trim()).filter(Boolean);
    const current=read(); current.currentAffairs=current.currentAffairs||[];
    let added=0;
    for(const feed of feeds){
      const r=await fetch(feed,{headers:{'User-Agent':'AATHVIK/8.0'}}); if(!r.ok) continue;
      const xml=await r.text();
      const items=[...xml.matchAll(/<item[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?(?:<link>([\s\S]*?)<\/link>)?[\s\S]*?(?:<pubDate>([\s\S]*?)<\/pubDate>)?[\s\S]*?<\/item>/gi)];
      for(const m of items.slice(0,20)){
        const title=String(m[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').replace(/<[^>]+>/g,'').trim();
        if(title && !current.currentAffairs.some(x=>x.title===title)){
          current.currentAffairs.unshift({title,link:String(m[2]||'').trim(),publishedAt:String(m[3]||new Date().toISOString()),source:feed});
          added++;
        }
      }
    }
    current.currentAffairs=current.currentAffairs.slice(0,100);
    current.version=(current.version||0)+1; current.updatedAt=new Date().toISOString();
    fs.writeFileSync(DATA,JSON.stringify(current,null,2));
    res.json({ok:true,added,version:current.version,updatedAt:current.updatedAt,feeds:feeds.length});
  }catch(e){res.status(500).json({error:e.message||'Refresh failed'});}
});

app.get('/health',(req,res)=>res.json({ok:true,fighter:!!OPENAI_API_KEY}));
// Safe production defaults: keep secrets server-side and never ship them in the APK.
app.get('/api/meta',(req,res)=>res.json({app:'AATHVIK',version:read().version||1,updatedAt:read().updatedAt||null,topics:read().topics?.length||0,freeFirst:FREE_FIRST,google:googleConfigured(),ai:!!OPENAI_API_KEY}));
app.listen(PORT,()=>console.log(`AATHVIK content API listening on ${PORT}`));
