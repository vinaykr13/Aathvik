const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 8080;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'change-this-token';
const DATA = path.join(__dirname, '..', 'content.json');
app.use(cors()); app.use(express.json({limit:'2mb'}));
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const FIGHTER_MODEL = process.env.FIGHTER_MODEL || 'gpt-5.6-luna';
function read(){ return JSON.parse(fs.readFileSync(DATA,'utf8')); }
app.get('/api/content',(req,res)=>res.json(read()));
app.put('/api/content',(req,res)=>{ if(req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({error:'Unauthorized'}); if(!req.body || !Array.isArray(req.body.topics)) return res.status(400).json({error:'Invalid content'}); const data={...req.body,version:(read().version||0)+1,updatedAt:new Date().toISOString()}; fs.writeFileSync(DATA,JSON.stringify(data,null,2)); res.json(data); });
app.post('/api/fighter', async (req,res)=>{
  try{
    if(!OPENAI_API_KEY) return res.status(503).json({error:'OPENAI_API_KEY is not configured'});
    const question=String(req.body?.question||'').trim();
    if(!question) return res.status(400).json({error:'Question is required'});
    if(question.length>8000) return res.status(400).json({error:'Question too long'});
    const r=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',
      headers:{'Authorization':`Bearer ${OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({
        model:FIGHTER_MODEL,
        instructions:'You are FIGHTER, a dedicated SSC CGL doubt-solving tutor. Answer in simple Hindi/Hinglish unless the user asks for English. Give the correct answer first, then step-by-step explanation, shortcut/trick where useful, and one similar practice question. For maths/reasoning, show calculations clearly. Do not invent facts. Keep the answer focused and exam-oriented.',
        input:question
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'OpenAI request failed'});
    const answer=data.output_text || (Array.isArray(data.output)?data.output.flatMap(x=>x.content||[]).map(x=>x.text||'').filter(Boolean).join('\n'):'');
    res.json({answer});
  }catch(e){res.status(500).json({error:e.message||'FIGHTER server error'});}
});
app.get('/health',(req,res)=>res.json({ok:true,fighter:!!OPENAI_API_KEY}));
app.listen(PORT,()=>console.log(`AATHVIK content API listening on ${PORT}`));
