# AATHVIK — Android App

Personal SSC CGL study app foundation. App branding is **AATHVIK**.

## Build on laptop
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync complete.
4. Build → Generate App Bundles or APKs → Generate APKs.

## Build online with GitHub Actions
1. Create a GitHub repository and upload this entire project.
2. Push the project to the `main` branch, or open **Actions → Build AATHVIK APK → Run workflow**.
3. After the workflow finishes, open the workflow run and download the **AATHVIK-debug-apk** artifact.

The repository includes a small `gradlew` bootstrap script so GitHub Actions can obtain Gradle automatically.

## Package
`com.aathvik.app`

## Current foundation
Dashboard, study library, topic theory/tricks, focus timer, mock tracker, progress/stats, local persistence, and FIGHTER UI are included. FIGHTER is currently a UI foundation; a secure backend/API connection is needed for live AI responses.
