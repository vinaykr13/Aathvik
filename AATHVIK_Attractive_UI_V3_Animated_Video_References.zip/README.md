# AATHVIK

A polished native Android SSC CGL personal study app.

## V2 UI
- Clean, crisp dark premium interface
- Entrance/card slide-fade animations and button press animations
- AATHVIK branded launcher icon
- Topic-wise Theory, Tricks, Examples
- Topic-wise Video button: opens an in-app YouTube search for the exact topic
- Topic-wise Reference button
- Trusted reference hub (SSC, NCERT, RBI, PIB)
- Local topic completion and study timer
- Mock test tracking, progress, FIGHTER doubt UI

## Build
Run `./gradlew :app:assembleDebug` or use GitHub Actions.

The APK artifact is `app/build/outputs/apk/debug/app-debug.apk`.
