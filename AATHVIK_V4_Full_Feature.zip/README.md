# AATHVIK V4

Personal SSC CGL study app foundation. App title is **AATHVIK**.

## Included in V4
- Premium dark native Android UI with lightweight animations
- Topic-wise starter theory, tricks and examples across Quant, Reasoning, English, History, Geography, Polity, Economy, Science, Static GK and Computer
- Topic completion and revision flags
- Topic-wise in-app YouTube search and web reference
- Trusted reference hub (SSC, NCERT, RBI, PIB)
- Daily task checklist
- Mistake book
- Starter question bank with answer reveal
- Mock-test tracker
- Focus timer and local persistence
- Progress analytics
- FIGHTER doubt-solver UI with image picker foundation
- GitHub Actions workflow that builds and uploads `AATHVIK-debug-apk`

## Important
This V4 is a strong working foundation, not a claim that every SSC CGL chapter, every PYQ, curated video, current-affairs feed, or live AI backend has been fully populated. FIGHTER requires a secure backend for live AI answers; never put an API secret in the APK.
